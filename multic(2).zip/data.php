<?php

// link
$link = "";

// User Agent
$ua = "";

